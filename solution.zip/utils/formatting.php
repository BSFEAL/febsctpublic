<?php

function format_date($date){
  $newDate = 

}

?>
