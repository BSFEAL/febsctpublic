<?php
/*
PERMISSIONS MANAGEMENT
*/
function check_permission($perm, $permissions){
  if(in_array($perm, $permissions)){
    return true;
  }
  // admin grant
  if(in_array('all', $permissions)){
    return true;
  }
  return false;
}

?>
