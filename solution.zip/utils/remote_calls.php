<?php
/*
User Mamangement
Version: 0.1
Author: Alan Ferrari [alan.ferrari@bancastato.ch]
*/

define("URL_SERVICE_USER", "http://159.69.83.224:5000/login");

define("URL_SEARCH_PARTNER", "http://159.69.83.224:5000/search_partners");
define("URL_GENERATE_CREL", "http://159.69.83.224:5000/generate_crel");
define("URL_FUSC_QUERY", "http://159.69.83.224:5000/fusc/search");
define("URL_FUSC_GET", "http://159.69.83.224:5000/fusc/get");
define("URL_FUSC_ALERTS", "http://159.69.83.224:5000/fusc/alerts");
define("URL_QAD_QUEST", "http://159.69.83.224:5001/question");
define("URL_QAD_GALL", "http://159.69.83.224:5001/get_sources");
//tickets
define("URL_SERVICE_TK_EXCEL", "http://159.69.83.224:5000/ticket/parse_excel");
define("URL_TK_USERS", "http://159.69.83.224:5000/ticket/get_users");
define("URL_TK_SAVE", "http://159.69.83.224:5000/ticket/new");
define("URL_TK_GET_ALL", "http://159.69.83.224:5000/ticket/search");
define("URL_TK_GET", "http://159.69.83.224:5000/ticket/get");
define("URL_TK_DELETE", "http://159.69.83.224:5000/ticket/delete");
define("URL_TK_UPDATE", "http://159.69.83.224:5000/ticket/update");

function login_user($username, $password){
  $params=  "?uname=" . $username ."&psw=" . $password;
  return remote_call_GET(URL_SERVICE_USER, $params, "");
}


function load_excel($path){
  $params=  "?path=" . $path;
  return remote_call_GET(URL_SERVICE_TK_EXCEL, $params);
}


function get_ticket_users(){
  $params=  "?n=p";

  return remote_call_GET(URL_TK_USERS, $params);
}



function search_partner_call($partner_id){
  $params=  "?partner_no=" . $partner_id;
  return remote_call_GET(URL_SEARCH_PARTNER, $params);
}

function generate_crel($partner_id){
  $params=  "?doc_extract=" . $partner_id;
  return remote_call_GET(URL_GENERATE_CREL, $params);
}


function fusc_query($query){
  $params=  "?query=" . $query;
  return remote_call_GET(URL_FUSC_QUERY, $params);
}


function fusc_get($id){
  $params=  "?id=" . $id;
  return remote_call_GET(URL_FUSC_GET, $params);
}

function fusc_alerts(){
  $params=  "?d=2" ;
  return remote_call_GET(URL_FUSC_ALERTS, $params);
}



function qad_do_query($query){
  $params= "?question=".$query ;
  return remote_call_GET(URL_QAD_QUEST, $params);
}


function qad_get_all(){
  $params= "?t=t" ;
  return remote_call_GET(URL_QAD_GALL, $params);
}


function save_tickets($json, $excel_path){
  $params= "?excel_path=".$excel_path."&changes=".$json;
  return remote_call_GET(URL_TK_SAVE, $params);
}

function get_tickets($query, $status, $date_from, $date_to){
  $params= "?";
  if(strlen($query) > 0){
      $params =$params."query=".$query."&";
  }

  if(strlen($status) > 0){
      $params =$params."status=".$status."&";
  }
  if(strlen($date_from) > 0){
      $params =$params."from=".$date_from."&";
  }
  if(strlen($date_to) > 0){
      $params =$params."to=".$date_to."&";
  }
  return remote_call_GET(URL_TK_GET_ALL, $params);
}

function get_single_ticket($id){
  $params= "?id=".$id;
  return remote_call_GET(URL_TK_GET, $params);
}


function delete_ticket($id){
  $params= "?id=".$id;
  return remote_call_GET(URL_TK_DELETE, $params);
}


function update_ticket($id, $values){
  $params= "?id=".$id."&params=".$values;
  return remote_call_GET(URL_TK_UPDATE, $params);
}


// remote calls
function remote_call_GET($request_url, $params) {
  /*
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $request_url . $params);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $response = curl_exec($ch);
  curl_close($ch);
  return $response;
  */
  return file_get_contents($request_url . $params);
}


?>
