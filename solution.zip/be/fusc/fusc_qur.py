"""
FUSC ES QUERY
(c) BancaStato 2021
Alan Ferrari(alan.ferrari@bancastato.ch)
"""

import configparser
import os.path
import hashlib
import docx

import sys

sys.path.append("./dbm/")

from es_manager import (
    es_connect,
    es_matching_query,
    text_query,
    last_days_query,
    get_element_by_id,
)

CONFIG_FILE = "./configs/dbconfig.ini"


def get_config(cf=CONFIG_FILE):
    config = configparser.ConfigParser()
    config.read(cf)
    return config


def get_es_connection_and_index():
    config = get_config(CONFIG_FILE)
    index = config["FUSC"]["fusc_es_index"]
    es = es_connect()
    return es, index


def query_fusc(
    es,
    index,
    query,
):
    return text_query(es, index, query, "last_update")


def get_recent_alerts(es, index, days=2):
    return last_days_query(es, index, "last_update", days)


def get_fuscelement_by_id(es, index, id):
    return get_element_by_id(es, index, id)


"""
def main():
    es, index = get_es_connection_and_index()
    # res = text_query(es, index, "matter")
    res = last_days_query(es, index, "last_update", 2)
    for r in res:
        print(r["_source"])


if __name__ == "__main__":
    main()
"""
