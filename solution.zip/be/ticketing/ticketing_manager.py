"""
Ticket Manager
- Gestione processi di ticketing
"""
import pandas as pd
import datetime
import math
import sys

sys.path.append("../")


from dbm import(
    es_connect,
    es_create_index,
    es_delete_index,
    es_insert_from_dict,
    es_matching_query,
    es_update_params,
    get_element_by_id,
    es_delete_by_id,
    text_query
)


TK_INDEX = "tkutils"

def parse_excel(file_path):
    xl = pd.read_excel(file_path)
    dt = xl.to_dict(orient="records")
    return _reformat_excel(dt)


def remove_first_end_spaces(string):
    return "".join(string.rstrip().lstrip())


def _get_dependencies(dep):
    if "None" in dep:
        return []
    return [remove_first_end_spaces(x) for x in dep.split(",")]



def _reformat_excel(js):
    output = []
    for j in js:
        if math.isnan(j["Interaction Related"]):
            continue
        ticket = {}
        ticket["interaction_related"] = j["Interaction Related"]
        ticket["incident_related"] = j["Incident Related"]
        ticket["id"] =  "{}_{}".format(int(ticket["incident_related"]), int(ticket["interaction_related"]))
        ticket["brief_description"] = j["Brief Description"]
        ticket["contact_person"] = j["Contact Person"]
        ticket["assignment"] = j["Assignment"]
        ticket["tester"] = []
        ticket["test"] = ""
        ticket["in_prod"] = ""
        ticket["osservazioni"] = ""
        dependencies = j["dep map"]
        ticket["dependencies_map"] = _get_dependencies(dependencies)
        output.append(ticket)
    return output



def save_tickets(changes, excel_path):
    """
    Generate and save in ES a set of tickets.
    """
    try:
        es = es_connect("./configs/dbconfig.ini")
    except Exception as e:
        print(e)
        return None

    try:
        #es_delete_index(es, TK_INDEX)
        es_create_index(es, TK_INDEX)
    except Exception as e:
        logger.debug("es index exists.")

    excel = parse_excel(excel_path)
    to_be_saved = []
    for e  in excel:
        id = e['id']
        if "on" not in changes["consider_{}".format(id)]:
            print("{} is not considered".format(id))
            continue

        due_date_s = changes["date_{}".format(id)]
        due_date =  datetime.datetime.strptime(due_date_s, '%m-%d-%Y')
        observations = changes["oss_{}".format(id)]

        user  = changes["{}_user".format(id)]

        e['due_date'] = due_date
        e['created'] =  datetime.datetime.now()
        e['observations'] = observations
        e["user"] = user
        e["status"] = "Open"
        e["outcome_text"] = ""
        e["files"] = {}
        to_be_saved.append(e)

    i = []
    for e in to_be_saved:
        print("Saving {}".format(e['id']))
        es.index(index=TK_INDEX, id=e['id'], body=e)
        i.append(e['id'])
    return i



def search_tickets(status=None, query=None, date_start=None, date_stop=None):
        """
        Search for the tickets

        # add date search
        """
        if date_start:
            try:
                date_start = datetime.datetime.strptime(date_start, '%m-%d-%Y')
            except Exception as e:
                print(e)
                date_start = None

        if date_stop:
            try:
                date_stop = datetime.datetime.strptime(date_stop, '%m-%d-%Y')
            except Exception as e:
                print(e)
                date_stop = None
        print("dates:")
        print(date_start, date_stop)
        if not status:
            status = "Open"
        try:
            es = es_connect("./configs/dbconfig.ini")
        except Exception as e:
            print(e)
            return None

        res = None
        if not query:
            query= {"match_all": {}}
            res = es_matching_query(es, TK_INDEX, query , sort_field="due_date")
        else:
            res = text_query(es, TK_INDEX, query , sort_field="due_date")

        if not res:
            return None


        clean_ds = []
        for r in res:
            if r["_source"]["status"].lower() == status.lower():

                date_s = datetime.datetime.strptime(r["_source"]["created"].split("T")[0], "%Y-%m-%d")

                if date_start and date_s < date_start:
                    continue

                if date_stop and date_s > date_stop:
                    continue

                clean_ds.append(r)

        return clean_ds



def get_single_ticket(id):
    try:
        es = es_connect("./configs/dbconfig.ini")
        return get_element_by_id(es, TK_INDEX, id)
    except Exception as e:
        print(e)
        return None


def update_ticket(id, value):
    try:
        es = es_connect("./configs/dbconfig.ini")
        ticket = get_element_by_id(es, TK_INDEX, id)
        ticket_val = ticket["_source"]
        ticket_val["status"] = value["status"]
        ticket_val["due_date"] = datetime.datetime.strptime(value["due_date"], '%m-%d-%Y')
        ticket_val["outcome_text"] = value["outcome_text"]
        ticket_val["observations"] = value["observations"]
        ticket_val["user"] = value["user_selected"]
        for f in  value["files"].keys():
            if len(f) > 0:
                ticket_val["files"][f] = value["files"][f]

        ticket["_source"] = ticket_val
        print("\n\n\n")
        print(value)
        print("\n\n\n")
        print(ticket)
        ret =  es_update_params(es,TK_INDEX, ticket)
        print("\n\n\n")
        print(ret)
        print("\n\n")
        return ret
    except Exception as e:
        print(e)
        return False



def delete_ticket(id):
    try:
        es = es_connect("./configs/dbconfig.ini")
        return es_delete_by_id(es, TK_INDEX, id)
    except Exception as e:
        print(e)
        return None
