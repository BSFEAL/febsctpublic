import unittest
import sys

sys.path.append("../dbm/")

from es_manager import es_connect, es_create_index


class TestStringMethods(unittest.TestCase):
    def test_connect(self):
        es = es_connect()
        self.assertEqual("foo".upper(), "FOO")


if __name__ == "__main__":
    unittest.main()
