curl -X GET "localhost:9200/_analyze?pretty" -H 'Content-Type: application/json' -d'
{
  "tokenizer": "standard",
  "filter": [ "stemmer" ],
  "text": "lavoratori indipendenti"
}
'



curl -X PUT "localhost:9200/bspropectsv3?pretty" -H 'Content-Type: application/json' -d'
{
  "settings": {
    "analysis": {
      "analyzer": {
        "default": {
          "type": "my_stemmer"
        }
      }
    }
  }
}
'


curl -X PUT "localhost:9200/bspropectsv3?pretty" -H 'Content-Type: application/json' -d'
{
  "settings": {
    "analysis": {
      "analyzer": {
        "my_analyzer": {
          "tokenizer": "standard",
          "filter": [
            "lowercase",
            "my_stemmer"
          ]
        }
      },
      "filter": {
    "my_stemmer": {
          "type": "stemmer",
          "language": "light_italian"
        }
      }
    }
  }
}
'

curl -X PUT "localhost:9200/bspropectsv3?pretty" -H 'Content-Type: application/json' -d'
{
  "mappings": {
    "properties": {
      "title": {
        "type": "text",
        "analyzer": "my_stemmer"
      },
      "text": {
        "type": "text",
        "analyzer": "my_stemmer"
      }
    }
  }
}
'

curl -X PUT "localhost:9200/bspropectsv3?pretty" -H 'Content-Type: application/json' -d'
{
  "settings": {
    "analysis": {
      "analyzer": {
        "default": {
          "type": "my_analyzer"
        }
      }
    }
  }
}
'



curl -X DELETE "localhost:9200/bspropectsv3?pretty"



curl -XPUT localhost:9200/bspropectsv3 -H 'Content-Type: application/json' -d'
{
"settings" : {
    "analysis" : {
        "analyzer" : {
            "stem" : {
                "tokenizer" : "standard",
                "filter" : ["standard", "lowercase", "stop", "porter_stem"]
            }
        }
    }
},
"mappings" : {
    "index_type_1" : {
        "dynamic" : true,
        "properties" : {
            "text" : {
                "type" : "string",
                "analyzer" : "stem"
            },
            "title" : {
                "type" : "string",
                "analyzer" : "stem"
            }
         }
      }
   }
}'
