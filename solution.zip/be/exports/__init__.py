from .rel_aff import search_partners
from .rel_aff import generate_word
