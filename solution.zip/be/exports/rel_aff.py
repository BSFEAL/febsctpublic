import configparser
import os.path
import hashlib
import docx


CONFIG_FILE = "configs/words.ini"

def get_config():
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE)
    return config



RL_AFF_MOCKING = [{
    "partner_no": 1235,
    "firt_name": "pinco",
    "last_name": "pallo",
    "address": "Somewhere",
    "tipo" :"Person",
    "birth_date": "11.11.1911",
    "testo": "testo"
},{
    "partner_no": 679,
    "firt_name": "Pallo",
    "last_name": "Pino",
    "address": "Somewhere Else",
    "tipo" :"Person",
    "birth_date": "22.22.1922",
    "testo": "testo2"
}
]




def get_partner_data(query):
    return PARTNER_INFO


def get_single_partner_info(partner_no):
    for p in RL_AFF_MOCKING:
        if p["partner_no"] == partner_no:
            return p
    return RL_AFF_MOCKING[0]

def generate_word(partner_no):
    config = get_config()
    words_template = config["RAF"]['model_path']
    out_path = config["RAF"]['out_path']
    doc = docx.Document(words_template)

    data = get_single_partner_info(partner_no)
    for p in doc.paragraphs:

        for d in data.keys():
            print(d)
            inline = p.runs
            # Loop added to work with runs (strings with same style)
            for i in range(len(inline)):
                if "{"+d+"}" in inline[i].text:
                    text = inline[i].text.replace("{"+d+"}", str(data[d]))
                    inline[i].text = text

    path= os.path.join(out_path, "CREL_"+str(partner_no)+".docx")
    doc.save(path)
    return "CREL_"+str(partner_no)+".docx"



def search_partners(partner_no):
    return RL_AFF_MOCKING

"""
print(generate_word(124))
"""
