echo "killing process" $(cat save_pid.txt)
kill -9 $(cat save_pid.txt)
nohup python3 run.py > /tmp/da.log 2>&1 &
echo $! > save_pid.txt
echo "Starting Service with PID" $(cat save_pid.txt)
echo "log stored in  /tmp/da.log"
