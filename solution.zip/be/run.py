####
# DABE Entry point
# Alan Ferrari (alan.ferrari@bancastato.ch  )
####

from flask import Flask, jsonify, request
app = Flask(__name__)


import json
import logging


from dbm import check_password, get_users, access_db
from ticketing import parse_excel, save_tickets, search_tickets, get_single_ticket, delete_ticket, update_ticket

# rel aff
from exports import search_partners, generate_word

# fusc
from fusc import (
    get_es_connection_and_index,
    query_fusc,
    get_recent_alerts,
    get_fuscelement_by_id,
)

ANYHOST = True

"""
GENERIC API
"""


@app.route("/")
def main():
    return jsonify({"Service: ": "BSDA Platform V1", "Status": "OK"})


@app.route("/login")
def login():
    username = request.args.get("uname")
    password = request.args.get("psw")
    try:
        return jsonify(check_password(username, password))
    except Exception as e:
        logging.warning(str(e))
        return jsonify({"status": False, "user": None})


"""
CREL API
"""


@app.route("/search_partners")
def partners():
    pno = request.args.get("partner_no")
    try:
        data = search_partners(pno)
        return jsonify({"status": True, "data": data})
    except Exception as e:
        logging.warning(str(e))
        return jsonify({"status": False, "data": str(e)})


@app.route("/generate_crel")
def generate_crel():
    pno = request.args.get("partner_no")
    try:
        data = generate_word(pno)
        return jsonify({"status": True, "data": data})
    except Exception as e:
        logging.warning(str(e))
        return jsonify({"status": False, "data": str(e)})


"""
FUSC API
"""


@app.route("/fusc/search")
def fusc_search():
    query = request.args.get("query")

    try:
        es, index = get_es_connection_and_index()
        raw = query_fusc(es, index, query)

        if not raw:
            return jsonify({"status": False, "data": "Element not found."})
        data = []
        for d in raw:
            element = d["_source"]
            element["id"] = d["_id"]
            data.append(element)

        return jsonify({"status": True, "data": data})
    except Exception as e:
        logging.warning(str(e))
        return jsonify({"status": False, "data": str(e)})


@app.route("/fusc/alerts")
def fusc_alerts():
    days = 2
    try:
        es, index = get_es_connection_and_index()
        raw = get_recent_alerts(es, index, days)

        if not raw:
            return jsonify({"status": False, "data": "Element not found."})
        data = []
        for d in raw:
            element = d["_source"]
            element["id"] = d["_id"]
            data.append(element)

        return jsonify({"status": True, "data": data})
    except Exception as e:
        logging.warning(str(e))
        return jsonify({"status": False, "data": str(e)})


@app.route("/fusc/get")
def fusc_get():
    id = request.args.get("id")

    try:
        es, index = get_es_connection_and_index()
        raw = get_fuscelement_by_id(es, index, id)
        if not raw:
            return jsonify({"status": False, "data": "Element not found."})
        data = []
        element = raw["_source"]
        element["id"] = raw["_id"]
        data.append(element)
        return jsonify({"status": True, "data": data})
    except Exception as e:
        logging.warning(str(e))
        return jsonify({"status": False, "data": str(e)})


"""
Ticketing API
"""

@app.route("/ticket/parse_excel")
def ticketing_excel():
    excel_path = request.args.get("path")
    try:
        data = parse_excel(excel_path)
        return jsonify({"status": True, "data": data})
    except Exception as e:
        logging.warning(str(e))
        print(e)
        return jsonify({"status": False, "data": str(e)})


@app.route("/ticket/get_users")
def get_tickets_users():
    db = access_db()
    users = get_users(db)
    return jsonify({"status": True, "data": users})



@app.route("/ticket/new")
def save_new_tickets():
    excel_path = request.args.get("excel_path")
    changes_json = request.args.get("changes")
    ret = save_tickets(json.loads(changes_json), excel_path)
    if not ret:
        return jsonify({"status": False, "data": "Unable to save the tickets"})
    ret= {"status": True, "data": ret}
    return jsonify(ret)


@app.route("/ticket/search")
def get_tickets():
    query = request.args.get("query")
    status = request.args.get("status")
    from_d = request.args.get("from")
    to_d = request.args.get("to")
    ret = search_tickets(status, query, from_d, to_d)

    data = {}
    for r in ret:
        data[r["_id"]] = r["_source"]

    return jsonify({"status": True, "data": data})


@app.route("/ticket/get")
def get_ticket():
    id = request.args.get("id")
    ret = get_single_ticket(id)

    if not ret:
        return jsonify({"status": False, "data": "id not found"})

    if ret["found"]:
        return  jsonify({"status": True, "data": ret["_source"]})

    return jsonify({"status": False, "data": "id not found"})


@app.route("/ticket/delete")
def delt():
    id = request.args.get("id")
    ret = delete_ticket(id)

    if not ret:
        return jsonify({"status": False, "data": "unable to delete {}".format(id)})

    return jsonify({"status": True, "data": {"id": id}})


@app.route("/ticket/update")
def update():
    id = request.args.get("id")
    params = request.args.get("params")
    params = json.loads(params)
    ret = update_ticket(id,params)
    if not ret:
        return jsonify({"status": False, "data": {"id": id}})
    return jsonify({"status": True, "data": {"id": id}})

if __name__ == "__main__":
    if ANYHOST:
        app.run(host="0.0.0.0")
    else:
        app.run()
