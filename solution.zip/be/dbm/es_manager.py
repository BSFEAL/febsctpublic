import configparser
import os.path
import hashlib
from elasticsearch import Elasticsearch
import time

DB_CONFIG_FILE = "./configs/dbconfig.ini"


def _get_config(config_file):
    config = configparser.ConfigParser()
    config.read(config_file)
    return config


def es_connect(config_file=DB_CONFIG_FILE):
    _es = None
    config = _get_config(config_file)
    _es = Elasticsearch(
        [{"host": config["ES"]["es_host"], "port": config["ES"]["es_port"]}]
    )
    if _es.ping():
        print(
            "Connected to ES on host="
            + config["ES"]["es_host"]
            + " port="
            + str(config["ES"]["es_port"])
        )
    else:
        print("Error in connecting to ES")
    return _es


def lock_for_es(es):
    while not es.ping():
        time.sleep(4)


def es_create_index(es, index_name):
    return es.indices.create(index=index_name, ignore=400)


def es_delete_index(es, index_name):
    es.indices.delete(index=index_name, ignore=[400, 404])


def es_insert_from_dict(es, index_name, data):
    for key in data.keys():
        item = data[key]
        es.index(index=index_name, id=key, body=item)


def es_matching_query(es, index_name, query, sort_field=None):
    """
    doc = {"query": query}
    res = es.search(index=index_name, body=doc)
    print(len(res["hits"]["hits"]))
    return res["hits"]
    """
    qr = {"query": query}
    import elasticsearch.helpers

    if sort_field:
        qr["sort"] = [{sort_field: {"order": "desc"}}]

    results = elasticsearch.helpers.scan(
        es,
        index=index_name,
        preserve_order=True,
        query=qr,
    )

    return results


def get_element_by_id(es, index_name, id):
    return es.get(index=index_name, id=id)


def text_query(es, index_name, text, sort_field=None):
    query = {}
    query["query_string"] = {
        "query": text,
        "default_operator": "AND",
    }
    return es_matching_query(es, index_name, query, sort_field)


def more_like_this(es, index_name, field, text):
    query = {}
    query["more_like_this"] = {
        "fields": [field],
        "min_term_freq": 1,
        "max_query_terms": 12,
        "like": text,
    }
    return es_matching_query(es, index_name, query)


def last_days_query(es, index_name, field, days=4):
    query = {}
    query["range"] = {field: {"gte": "now-{}d/d".format(days), "lte": "now/d"}}

    return es_matching_query(es, index_name, query, field)


def get_all(es, index_name):
    query = {"match_all": {}}
    return es_matching_query(es, index_name, query)


def es_update_params(es, index_name, res):
    return es.update(
        index=index_name,
        doc_type=res["_type"],
        id=res["_id"],
        body={"doc": res["_source"]},
    )


def es_delete_by_id(es,index_name, id):
    return es.delete(index=index_name,id=id)
