from tinydb import TinyDB, Query
import configparser
import os.path
import hashlib


DB_CONFIG_FILE = "./configs/dbconfig.ini"

def get_config():
    config = configparser.ConfigParser()
    config.read(DB_CONFIG_FILE)
    return config


def access_db():
    config = get_config()
    tiny_db_file =  config["TINYDB"]["db_file"]
    if not os.path.isfile(tiny_db_file):
        db = TinyDB(tiny_db_file)
        password = hashlib.sha512(b"admin").hexdigest()
        db.insert({'type':'user', 'firstname': 'Admin', 'lastname': "Admin", "middlename": "", "username": "admin", "password": password, "e-mail": "", "permissions": ["all"]})
        for i in range(1,4):
            db.insert({'type':'user','firstname': 'TicketTest{}'.format(i), 'lastname': "TT", "middlename": "", "username": "ts{}".format(i), "password": password, "e-mail": "", "permissions": ["ticket"]})

    else:
        db = TinyDB(tiny_db_file)
    return db


def get_users(db):
    User = Query()
    users = db.search(User.type == 'user')
    ret_users = []
    for u in users:
        if 'ticket' in u["permissions"] or "all" in  u["permissions"]:
            ret_users.append({
                "firstname": u['firstname'],
                "middlename": u['middlename'],
                "lastname": u['lastname'],
                "username" : u['username'],
                })

    return ret_users



def query_user_db(username, db):
    User = Query()
    return db.search(User.username == username)



def check_password(username, password):
    db = access_db()
    user = query_user_db(username, db)
    password =  hashlib.sha512(password.encode('utf-8')).hexdigest()
    if len(user) < 1:
        return {"status": 'false', "user": "Anonymous"}
    if user[0].get("password", "") == password:
        u = user[0]
        del u['password']
        return {"status": 'true', "user" :u}
    else:
        return {"status": 'false', "user": "Anonymous"}
