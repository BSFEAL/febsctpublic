from os import walk

# import PyPDF2
from langdetect import detect
import sys

sys.path.append("../../dbm/")
from es_manager import (
    es_connect,
    es_create_index,
    es_delete_index,
    es_matching_query,
    es_update_params,
    es_insert_from_dict,
    lock_for_es,
)

DIR = "./pdfs/"

import spacy

nlp = spacy.load("it_core_news_lg")


def parse_doc(query_input, tolist=False):
    doc = nlp(query_input)
    if tolist:
        query = []
    else:
        query = ""
    for token in doc:
        print(token.text, token.pos_)
        if token.pos_ in ["NOUN", "PROPN", "ADJ"]:  # "ADJ", "VERB"
            if not tolist and len(query) > 0:
                query += " "
            if tolist:
                query.append(token.lemma_)
            else:
                query += token.lemma_
    return query


def pdfs_formatting(text):
    return text.replace("Š", ",")


def main():

    try:
        es = es_connect("../../configs/dbconfig.ini")
    except Exception as e:
        logger.error(e)
        return None

    lock_for_es(es)

    documents = {}

    with open("input_bs.txt", "r") as tf:
        text = tf.read()

    paragraphs = text.split("\n\n")
    id = 0
    for para in paragraphs:
        document = {}
        lines = para.split("\n")
        text = ""
        for line in lines:
            if line.startswith("TITLE:"):
                document["title"] = line.replace("TITLE:", "")
                text = " ".join([text, line.replace("TITLE:", "") + "."])
            elif line.startswith("URL:"):
                document["URL"] = line.replace("URL:", "")
            else:
                text = " ".join([text, line])
        document["text"] = text
        document["ltext"] = parse_doc(text)
        documents[id] = document
        id += 1

    es_insert_from_dict(es, "bspropectsv3", documents)


if __name__ == "__main__":
    main()
