echo "killing process" $(cat save_pidc.txt)
kill -9 $(cat save_pidc.txt)
nohup python3 run.py > /tmp/chatbot.log 2>&1 &
echo $! > save_pidc.txt
echo "Starting Service with PID" $(cat save_pidc.txt)
echo "log stored in  /tmp/chatbot.log"
