import json
from transformers import pipeline
import sys
import spacy
import re

nlp = spacy.load("it_core_news_lg")

MAX_DOC_SEARCH = 10

sys.path.append("../../dbm/")
from es_manager import (
    es_connect,
    es_create_index,
    es_delete_index,
    es_matching_query,
    es_update_params,
    es_insert_from_dict,
    lock_for_es,
    more_like_this,
    text_query,
    get_all,
)

## init the pipeline
nlp_qa = pipeline(
    "question-answering",
    model="mrm8488/bert-italian-finedtuned-squadv1-it-alfa",
    tokenizer="mrm8488/bert-italian-finedtuned-squadv1-it-alfa",
)


def sentence_tokenizer(text, pattern):
    ret = ""
    count = 0
    sentences = re.split(r' *[\.\?!][\'"\)\]]* *', text)
    for s in sentences:
        if pattern in s:
            split = s.split(pattern)
            if len(split) < 2:
                return pattern
            return split[0] + " <b>" + pattern + "</b> " + split[1]
    return pattern


def prepare_query_for_es(query_input):
    doc = nlp(query_input)
    query = ""
    for token in doc:
        # print(token.text, token.pos_)
        if token.pos_ in ["NOUN", "PROPN"]:  # "ADJ", "VERB"
            if len(query) > 0:
                query += " "
            query += token.text
    return query


def do_query(question):
    try:
        es = es_connect("../../configs/dbconfig.ini")
    except Exception as e:
        print(e)
        exit()
    index_name = "bspropectsv2"
    text_query = prepare_query_for_es(question)
    query = {
        "query_string": {
            "query": text_query,
            "default_field": "text",
        }
    }

    # ret = more_like_this(es, index_name, "text", "filiali")
    ret = es_matching_query(es, index_name, query)
    best_answer = ""
    best_score = 0
    best_doc = None
    past_score = 0

    stop_search = MAX_DOC_SEARCH
    for r in ret:
        # print(r["_source"]["title"])
        out = nlp_qa({"question": question, "context": r["_source"]["text"]})
        # print(out)
        gscore = r["_score"] * out["score"]
        diff = past_score - gscore

        if gscore > best_score:
            best_answer = out["answer"]
            best_score = gscore
            best_doc = r

        if stop_search == 0:
            break
        stop_search -= 1

    if not best_doc:
        print("Nessuna risposta trovata")
        return

    print("Miglior Risposta:")
    print("Risposta: {}".format(best_answer))
    print("Score {}".format(best_score))
    print(
        'Documento "{}| con url: "{}"'.format(
            best_doc["_source"]["title"], best_doc["_source"]["URL"]
        )
    )
    print(sentence_tokenizer(best_doc["_source"]["text"], best_answer))
    print("\n\n")


def main():
    while True:
        question = input("Domanda: ")
        do_query(question)


if __name__ == "__main__":
    main()
