import json
from transformers import pipeline
import sys
import spacy
import re


MAX_DOC_SEARCH = 10
DEFAULT_INDEX = "bspropectsv3"


RANKING_DELTA = 0.8
ANSER_DELTA = 0.2

sys.path.append("../../dbm/")
from es_manager import (
    es_connect,
    es_create_index,
    es_delete_index,
    es_matching_query,
    es_update_params,
    es_insert_from_dict,
    lock_for_es,
    more_like_this,
    text_query,
    get_all,
)

# init spacy
nlp = spacy.load("it_core_news_lg")


## init the pipeline
nlp_qa = pipeline(
    "question-answering",
    model="mrm8488/bert-italian-finedtuned-squadv1-it-alfa",
    tokenizer="mrm8488/bert-italian-finedtuned-squadv1-it-alfa",
)


def sentence_tokenizer(text, pattern):
    ret = ""
    count = 0
    sentences = re.split(r' *[\.\?!][\'"\)\]]* *', text)
    for s in sentences:
        if pattern in s:
            split = s.split(pattern)
            if len(split) < 2:
                return pattern
            return split[0] + " <b>" + pattern + "</b> " + split[1]
    return pattern


def prepare_query_for_es(query_input, tolist=False):
    doc = nlp(query_input)
    if tolist:
        query = []
    else:
        query = ""
    for token in doc:
        print(token.text, token.pos_)
        if token.pos_ in ["NOUN", "PROPN", "ADJ"]:  # "ADJ", "VERB"
            if not tolist and len(query) > 0:
                query += " "
            if tolist:
                query.append(token.lemma_)
            else:
                query += token.lemma_
    return query


def do_query(question, index_name=DEFAULT_INDEX):
    try:
        es = es_connect("../../configs/dbconfig.ini")
    except Exception as e:
        print(e)

    text_query = prepare_query_for_es(question)
    query = {"query_string": {"query": text_query, "default_field": "ltext"}}

    # ret = more_like_this(es, index_name, "text", "filiali")
    ret = es_matching_query(es, index_name, query)
    best_answer = ""
    best_score = 0
    best_doc = None
    past_score = 0

    stop_search = MAX_DOC_SEARCH
    for r in ret:
        # print(r["_source"]["title"])
        out = nlp_qa({"question": question, "context": r["_source"]["text"]})
        # print(out)
        gscore = (RANKING_DELTA * r["_score"]) + (ANSER_DELTA * out["score"])
        diff = past_score - gscore

        if gscore > best_score:
            best_answer = out["answer"]
            best_score = gscore
            best_doc = r

        if stop_search == 0:
            break
        stop_search -= 1

    if not best_doc:
        print("Nessuna risposta trovata")
        return {"status": False, "data": "Nessuna risposta trovata"}

    ret = {}
    ret["status"] = True
    ret["data"] = {}
    ret["data"]["answer"] = best_answer
    ret["data"]["score"] = best_score
    ret["data"]["source"] = best_doc["_source"]["title"]
    ret["data"]["source_url"] = best_doc["_source"]["URL"]
    ret["data"]["extract"] = sentence_tokenizer(
        best_doc["_source"]["text"], best_answer
    )
    return ret


def get_all_sources(es_index=DEFAULT_INDEX):
    try:
        es = es_connect("../../configs/dbconfig.ini")
        data = get_all(es, es_index)
        return {"status": True, "data": data}
    except Exception as e:
        return {"status": False, "data": str(e)}
