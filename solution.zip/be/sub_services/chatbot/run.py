from bsbot import do_query, get_all_sources
from flask import Flask, jsonify, request

app = Flask(__name__)
import logging

ANYHOST = True

PORT = 5001


@app.route("/")
def main_route():
    return jsonify({"Service: ": "BS CHATBOT V1", "Status": "OK"})


@app.route("/question")
def ask_question():
    question = request.args.get("question")
    try:

        if "esindex" in request.args:
            esindex = request.args.get("esindex")
            return jsonify(do_query(question, esindex))
        else:
            return jsonify(do_query(question))
    except Exception as e:
        logging.warning(str(e))
        return jsonify({"status": False, "data": None})


@app.route("/get_sources")
def get_all_docs():
    try:
        sources = {}
        items = None
        if "esindex" in request.args:
            esindex = request.args.get("esindex")
            items = get_all_sources(esindex)
        else:
            items = get_all_sources()

        if not items["status"]:
            return jsonify({"status": False, "data": "empty items"})
        for s in items["data"]:
            sources[s["_id"]] = s["_source"]
        return jsonify({"status": True, "data": sources})
    except Exception as e:
        logging.warning(str(e))
        return jsonify({"status": False, "data": None})


if __name__ == "__main__":
    if ANYHOST:
        app.run(host="0.0.0.0", port=PORT)
    else:
        app.run()
