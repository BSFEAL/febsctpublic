from nltk.corpus import wordnet
import spacy

synonyms = []
antonyms = []

nlp = spacy.load("it_core_news_lg")


def get_syn(word):
    for syn in wordnet.synsets(word):
        for l in syn.lemmas(lang="ita"):
            synonyms.append(l.name())
            if l.antonyms():
                antonyms.append(l.antonyms()[0].name())
    print(set(synonyms))
    print(set(antonyms))


get_syn("succursale")

# prepare_query_for_es("quali carte sono incluse nel pacchetto giovane?")
