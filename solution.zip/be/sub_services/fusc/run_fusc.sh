nohup python3 run.py > /tmp/fusc.log 2>&1 &
