"""
(c) BancaStato 2021
"""
import configparser
import sys
import requests
import json
import xmltodict
from datetime import datetime, date, timedelta
import logging
import logging.config
import os.path
import hashlib


sys.path.append("../../dbm/")
from es_manager import (
    es_connect,
    es_create_index,
    es_delete_index,
    es_matching_query,
    es_update_params,
    lock_for_es,
)

CONFIG_FILE = "./fusc_config.ini"
DATE_FORMAT = "%Y-%m-%d"


def get_logging(log_path):
    """
    logging.basicConfig(
        filename=log_path,
        level=logging.DEBUG,
        format="[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s",
        datefmt="%H:%M:%S",
    )
    """

    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger("chardet.charsetprober").setLevel(logging.WARNING)
    logging.getLogger("urllib3.connectionpool").setLevel(logging.WARNING)
    logging.getLogger("elasticsearch").setLevel(logging.WARNING)

    return logger


def _get_config(config_file):
    config = configparser.ConfigParser()
    config.read(config_file)
    return config


def prepare_daily_list_url(fusc_url, start_date, stop_date, page=0):
    # GET FUSC QUERY URL
    return fusc_url.format(start_date, stop_date, page)


def get_element(url):
    # GET SINGLE FUSC ELEMENT
    response = requests.get(url)
    return xmltodict.parse(response.text)


def clean_name(name):
    name = name.replace("in liquidazione", "")
    name = name.replace("in Liquidation", "")
    name = name.replace("en liquidation", "")
    name = name.replace("EN LIQUIDATION", "")
    name = name.rstrip()
    return name


out_unknown = []


def get_data_interval(fusc_url, start_date, stop_date, page, logger):
    """
    FUSC PARSING: Produces a dict id:entry of entries for the selected time range.
    """
    url = prepare_daily_list_url(fusc_url, start_date, stop_date, page)

    response = requests.get(url)

    xpars = xmltodict.parse(response.text)

    items_count = xpars["bulk:bulk-export"]["total"]
    out = {}
    ct = 0
    print(items_count)
    for key in xpars["bulk:bulk-export"]["publication"]:
        url = key["@ref"]
        try:
            ele = get_element(url)
        except Exception as e:
            logger.error(str(e))
            continue
        output_dict = json.loads(json.dumps(ele))
        key = list(output_dict.keys())[0]
        element = output_dict[key]
        clean_data = {}
        if "debtor" not in element["content"]:
            out_unknown.append(element)
            logger.error(json.dumps(element["content"], indent=4, sort_keys=True))
            continue
        type = element["content"]["debtor"]["selectType"]
        if type == "company":
            info = element["content"]["debtor"]["companies"]["company"]
            name = info["name"]
            prename = ""
            if "address" not in info.keys():
                address = info.get("customAddress", "Unknown ")
                # print(json.dumps(info, indent=4, sort_keys=True))
            else:
                address = (
                    info["address"].get("street", "")
                    + " + "
                    + info["address"].get("houseNumber", "")
                    + "\n"
                    + info["address"]["swissZipCode"]
                    + " "
                    + info["address"]["town"]
                )

        elif type == "generalNotice":
            out_unknown.append(element)
            logger.error(json.dumps(element, indent=4, sort_keys=True))
            continue
        else:
            info = element["content"]["debtor"][type]
            name = info["name"]
            prename = info["prename"]
            if "addressSwitzerland" not in info:
                if "addressForeign" not in info:
                    address = "Unknown"
                    # print(json.dumps(info, indent=4, sort_keys=True))
                else:
                    address = (
                        info["addressForeign"]["addressCustomText"]
                        + " "
                        + info["addressForeign"]["country"]["name"]["en"]
                    )
            else:
                address = (
                    info["addressSwitzerland"].get("street", "")
                    + " "
                    + info["addressSwitzerland"].get("houseNumber", "")
                    + "\n"
                    + info["addressSwitzerland"].get("swissZipCode", "")
                    + " "
                    + info["addressSwitzerland"].get("town", "")
                )
            origin = info.get("countryOfOrigin", {"name": {"en": "Unknown"}})["name"][
                "en"
            ]
            clean_data["country_origin"] = origin
            dob = info.get("dateOfBirth", "1900-1-1")
            dod = info.get("dateOfDeath", "1900-1-1")

            dob = datetime.strptime(dob, DATE_FORMAT)
            dod = datetime.strptime(dod, DATE_FORMAT)

            clean_data["date_of_birth"] = dob
            clean_data["date_of_death"] = dod

        # debtor infos
        clean_data["name"] = clean_name(name)
        clean_data["prename"] = clean_name(prename)
        clean_data["type"] = type
        clean_data["address"] = address
        dop = element["meta"]["publicationDate"]

        clean_data["timestamp"] = datetime.strptime(dop, DATE_FORMAT)
        clean_data["remarks"] = element["content"].get("remarks", "")

        # meta info
        meta = element["meta"]

        clean_data["registration_office_name"] = meta["registrationOffice"][
            "displayName"
        ]
        address_reg = (
            meta["registrationOffice"].get("street", "")
            + " "
            + meta["registrationOffice"].get("registrationOffice", "")
            + "\n"
            + meta["registrationOffice"]["swissZipCode"]
            + " "
            + meta["registrationOffice"]["town"]
        )
        clean_data["registration_office_address"] = address_reg

        clean_data["legal_remedy"] = meta.get("legalRemedy", "")
        clean_data["title"] = meta["title"]["it"]
        clean_data["title_en"] = meta["title"]["en"]

        out[meta["id"]] = clean_data
    return out, items_count, xpars


def save_update_person(es, index_name, key, item):
    query = {}
    query["bool"] = {
        "should": [
            {"match": {"name": item["name"]}},
            {"match": {"prename": item["prename"]}},
            {"match": {"date_of_birth": item["date_of_birth"]}},
        ]
    }

    res = es_matching_query(es, index_name, query)

    hits = []
    if not res:
        for r in res:
            hits.append(r)

    entry = {}
    entry["id"] = key
    entry["legal_remedy"] = item["legal_remedy"]
    entry["registration_office_address"] = item["registration_office_address"]
    entry["registration_office_name"] = item["registration_office_name"]
    entry["remarks"] = item["remarks"]
    entry["timestamp"] = item["timestamp"]
    entry["title"] = item["title"]
    entry["title_en"] = item["title_en"]

    if len(hits) == 0:
        user = {}
        user["name"] = item["name"]
        user["prename"] = item["prename"]
        user["date_of_birth"] = item["date_of_birth"]
        user["date_of_death"] = item["date_of_death"]
        user["country_origin"] = item["country_origin"]
        user["address"] = item["address"]
        user["last_update"] = item["timestamp"]
        user["last_title"] = item["title"]

        user["entries"] = [entry]
        user["type"] = "person"
        m = hashlib.md5()
        key = user["name"] + "_" + user["prename"] + "_" + str(user["date_of_birth"])
        m.update(key.encode("utf8"))
        es.index(index=index_name, id=m.hexdigest(), body=user)
    else:
        val = hits[0]
        val["_source"]["entries"].append(entry)
        val["_source"]["last_update"] = entry["timestamp"]
        val["_source"]["last_title"] = entry["title"]
        es_update_params(es, index_name, val)


def save_update_enterprise(es, index_name, key, item):
    query = {}
    query["bool"] = {
        "should": [
            {"match": {"name": item["name"]}},
        ]
    }

    res = es_matching_query(es, index_name, query)

    hits = []
    if not res:
        for r in res:
            hits.append(r)
    entry = {}
    entry["id"] = key
    entry["legal_remedy"] = item["legal_remedy"]
    entry["registration_office_address"] = item["registration_office_address"]
    entry["registration_office_name"] = item["registration_office_name"]
    entry["remarks"] = item["remarks"]
    entry["timestamp"] = item["timestamp"]
    entry["title"] = item["title"]
    entry["title_en"] = item["title_en"]

    if len(hits) == 0:
        user = {}
        user["name"] = item["name"]
        user["address"] = item["address"]
        user["last_update"] = item["timestamp"]
        user["last_title"] = item["title"]

        user["entries"] = [entry]
        user["type"] = "company"
        m = hashlib.md5()
        key = user["name"]
        m.update(key.encode("utf8"))
        es.index(index=index_name, id=m.hexdigest(), body=user)
    else:
        val = hits[0]
        val["_source"]["entries"].append(entry)
        val["_source"]["last_update"] = entry["timestamp"]
        val["_source"]["last_title"] = entry["title"]
        es_update_params(es, index_name, val)


def insert_from_dict(es, index_name, data, logger):
    for key in data.keys():
        item = data[key]
        if item["type"] == "person":
            save_update_person(es, index_name, key, item)
        else:
            save_update_enterprise(es, index_name, key, item)


def do_round(conf, logger, day=None, day_end=None):
    exception = []
    try:
        es = es_connect("../../configs/dbconfig.ini")
    except Exception as e:
        logger.error(e)
        return None

    # fusc_query_url = conf["FUSC"]["rest_query_url"]
    fusc_query_url = "https://amtsblattportal.ch/api/v1/publications/xml?publicationStates=PUBLISHED&publicationDate.start={}&publicationDate.end={}&page={}"

    fusc_out_staus = conf["FUSC"]["fusc_out_staus"]
    fusc_es_index = conf["FUSC"]["fusc_es_index"]

    try:
        # es_delete_index(es, fusc_es_index)
        es_create_index(es, fusc_es_index)
    except Exception as e:
        logger.debug("es index exists.")
    fusc_config = None
    if not day and os.path.isfile(fusc_out_staus):
        with open(fusc_out_staus, "r") as fr:
            fusc_config = json.load(fr)
    if not fusc_config:
        fusc_config = {}
        yesterday = datetime.now() - timedelta(1)
        fusc_config["last_update"] = yesterday.strftime(DATE_FORMAT)

    if day:
        fusc_config = {}
        fusc_config["last_update"] = day

    if datetime.now().strftime(DATE_FORMAT) == fusc_config["last_update"]:
        logger.debug("FUSC Entry already loaded.")
        exit()
    page = 0
    tot = 0
    try:
        while True:
            logger.debug("Loading data from FUSC")
            if not day_end:
                day_end = datetime.now().strftime(DATE_FORMAT)
            print(fusc_config["last_update"], day_end)
            data, items_count, xpars = get_data_interval(
                fusc_query_url,
                fusc_config["last_update"],
                day_end,
                str(page),
                logger,
            )

            logger.debug("Loaded {} elements".format(len(data)))
            lock_for_es(es)
            logger.debug("Insert into ES")
            insert_from_dict(es, fusc_es_index, data, logger)

            tot += len(data)
            logger.debug("Inserted {} in ES items over {}".format(tot, items_count))
            page += 1

    except Exception as e:
        logger.error(str(e))
        # res = "".join(traceback.format_exception(type(e)), e, e.__traceback__)
        logger.error("# page {} saved".format(page))

    fusc_config["last_update"] = datetime.now().strftime(DATE_FORMAT)
    if not day:
        with open(fusc_out_staus, "w") as jf:
            json.dump(fusc_config, jf)
    logger.error("Result save into {}".format(fusc_out_staus))


def get_interval(days=500):

    a = datetime.today()
    numdays = days
    interval_list = []
    for x in reversed(range(0, numdays)):
        fr = a - timedelta(days=x + 1)
        to = a - timedelta(days=x)
        interval_list.append(
            {
                "from": fr.strftime(DATE_FORMAT),
                "to": to.strftime(DATE_FORMAT),
            }
        )
    return interval_list


def main():
    conf = _get_config(CONFIG_FILE)

    log_path = conf["FUSC"]["log_path"]
    logger = get_logging(log_path)
    interval = get_interval()
    """
    for i in interval:
        try:
            logger.debug("Loading From {} to {}".format(i["from"], i["to"]))
            do_round(conf, logger, day=i["from"], day_end=i["to"])
            logger.debug("End of Loading - From {} to {}".format(i["from"], i["to"]))
        except Exception as e:
            logger.error("Main Exception: " + str(e))
    """
    try:
        do_round(conf, logger)
    except Exception as e:
        logger.error("Main Exception: " + str(e))

    with open("out_exception.json", "w") as jf:
        json.dump(out_unknown, jf)


if __name__ == "__main__":
    main()
