
<h3><i class="fa fa-angle-right"></i>  Banca Stato Data - Data Analytics Portal (Beta.1) </h3>


<div class="row mt">
  <div class="col-lg-12">
    <div class="form-panel">
<h4> Per info contattare:</h4> </br>
    Alan Ferrari</br>
    alan.ferrari@bancastato.ch</br>
    +41 91 803 75 46 </br>
    </div>
</div>
<div>
