<?php

function get_section($section){
  if($section == "ticket"){
    include_once("sections/ticket.php");
  }elseif($section == "tmot") {
    include_once("sections/ticket_user.php");
  }elseif($section == "relaff") {
    include_once("sections/rel_aff_extraction.php");
  }elseif($section == "fusc") {
    include_once("sections/fusc.php");
  }elseif($section == "qad") {
    include_once("sections/qad.php");
  }elseif($section == "qads") {
    include_once("sections/qads.php");
  }else{
      include_once("sections/dashboard.php");
  }
}


?>
