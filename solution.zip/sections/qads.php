<?php
include_once("utils/remote_calls.php");

$return = json_decode(qad_get_all(), true);
$documents = array();
if($return['status'] == 1){
  $documents =  $return['data'];
}else{
?>
Nessun documento trovato.
<?php
  }
?>
<div class="form-panel">
<h4 class="mb"><i class="fa fa-angle-right"></i> Lista documenti per Q&amp;A:</h4>
<section id="no-more-tables">
  <table class="table table-bordered table-striped table-condensed cf">
    <thead class="cf">
      <tr>
        <th>Titolo</th>
        <th>Sorgente</th>
        <th>Testo</th>
      </tr>
    </thead>
    <tbody>

<?php
foreach($documents as $document){
$url = "index_admin.php?section=fusc&action=alerts&id=".$u['id']
?>
  <tr>
    <td data-title="Titolo"><?php echo $document['title']; ?></td>
    <td data-title="Sorgente"><a href="<?php echo $document['URL']; ?>" target="_blank"><?php echo $document['title'];  ?></a></td>
    <td data-title="Testo"><?php echo $document['text']; ?></td>
  </tr>
<?php
} //end foreeach

?>

    </tbody>
  </table>
</section>
</div>
