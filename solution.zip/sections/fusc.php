<h3><i class="fa fa-angle-right"></i> FUSC</h2>
<?php
if(array_key_exists("action", $_GET)){
  $action = $_GET["action"];
  if($action == "search"){
    include_once("./sections/fusc_search.php");
  }elseif($action == "alerts"){
    include_once("./sections/fusc_alerts.php");
  }
}

?>
