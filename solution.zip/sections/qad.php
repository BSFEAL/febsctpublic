<h3><i class="fa fa-angle-right"></i> BancaStato Q&amp;A - Demo</h2>
<div class="row mt">
  <div class="col-lg-12">
    <div class="form-panel">
      <h4 class="mb"><i class="fa fa-angle-right"></i> Domanda:</h4>
      <form class="form-inline" role="form" action="index_admin.php?section=qad&action=query" method="POST">
        <div class="form-group">
          <label class="sr-only" for="exampleInputEmail2"></label>
          <?php
          $value ="";

          if(array_key_exists("query_param", $_POST)){
              $value =  $_POST['query_param'];
          }
          ?>
            <input type="text" class="form-control" id="query_param" name="query_param"
            value="<?php echo $value; ?>"
            placeholder="Inserisci la tua domanda"
            size="100">
        </div>
        <button type="submit" class="btn btn-theme">Ricerca</button>
      </form>
    </div>
  </div>
</div>

<?php
$value ="";
if(array_key_exists("query_param", $_POST)){
    $value =  urlencode($_POST['query_param']);
    include_once("utils/remote_calls.php");
    $item = json_decode(qad_do_query($value), true);
    if($item['status'] == 1){
      $item= $item['data'];
      ?>
      <div class="form-panel">
      <h4 class="mb"><i class="fa fa-angle-right"></i> Risultato:</h4>
      <b>Risposta: </b> <?php echo $item["answer"]; ?><br/><br/-->
      <b>Estratto:</b><br/><?php echo $item["extract"]; ?><br/><br/>
      <b>Sorgente: </b><a href="<?php echo $item["source_url"]; ?> " target="_blank"> <?php echo $item["source"]; ?> </a>
      </div>
      <?php
    }

else{
      ?>
      <div class="form-panel">
      <b> Errore: </b> <?php echo $item['data']; ?>
      </div>
      <?php
    }

}
?>
