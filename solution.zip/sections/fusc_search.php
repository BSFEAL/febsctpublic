<div class="row mt">
  <div class="col-lg-12">
    <div class="form-panel">
      <h4 class="mb"><i class="fa fa-angle-right"></i> Ricerca:</h4>
      <form class="form-inline" role="form" action="index_admin.php?section=fusc&action=search&query" method="POST">
        <div class="form-group">
          <label class="sr-only" for="exampleInputEmail2"></label>
          <?php
          $value ="";
          if(array_key_exists("query", $_GET)){
            if(array_key_exists("id", $_GET)){
              $value =  $_GET['query'];
            }else{
              $value =  $_POST['query_param'];
            }
          }
          ?>
            <input type="text" class="form-control" id="query_param" name="query_param"
            value="<?php echo $value; ?>"
            placeholder="Inserisci la query">


        </div>
        <button type="submit" class="btn btn-theme">Ricerca</button>
      </form>
    </div>
  </div>
</div>

<?php
include_once("utils/remote_calls.php");
if(array_key_exists("query", $_GET)){
  if(array_key_exists("id", $_GET)){
    $query_param =  $_GET['query'];
    $item = json_decode(fusc_get($_GET["id"]), true);
    if($item['status'] == 1){
      $item =  $item['data'][0];
?>
<div class="form-panel">
<h4 class="mb"><i class="fa fa-angle-right"></i> <?php echo $item["name"]." ".$item["prename"]; ; ?></h4>
<b> Tipo</b>
<?php echo $item["type"]; ?><br/><br/>
<?php if($item["type"] == "person"){ ?>
  <b> Data di Nascita</b><br/>
  <?php echo  date("d-m-Y", strtotime($item["date_of_birth"])); ?><br/><br/>
  <?php if($item["date_of_death"] !="1900-01-01T00:00:00"){ ?>
  <b> Data di Morte</b> <br/>
  <?php echo  date("d-m-Y", strtotime($item["date_of_death"])); ?><br/><br/>
<?php }

} ?>

<b> Address</b> <br/>
<?php echo $item["address"]; ?><br/><br/>
<b>Ultimo Evento (<?php echo date("d-m-Y", strtotime($item['last_update'])); ?>)</b><br/>
<?php echo $item['last_title'] ?><br/><br/>
<section id="no-more-tables">  <table class="table table-bordered table-striped table-condensed cf">
  <table class="table table-bordered table-striped table-condensed cf">
    <thead class="cf">
      <tr>
        <th>Data</th>
        <th>Titolo</th>
        <th>Ufficio Responsabile</th>
        <th> Rimedio Legale</th>
        <th> Remarks</th>
      </tr>
    </thead>
    <tbody>
<?php
foreach($item["entries"] as $entry){
?>
<tr>
  <td data-title="Data"><?php echo  date("d-m-Y", strtotime($entry['timestamp'])); ?></td>
  <td data-title="Titolo"><?php echo $entry["title"] ?></td>
  <td data-title="Ufficio Responsabile"><?php echo $entry["registration_office_name"] ?></td>
  <td data-title="Rimedio Legale"><?php echo $entry["legal_remedy"] ?></td>
  <td data-title="Remarks"><?php echo $entry["remarks"] ?></td>
</tr>


<?php

}

?>
  </tbody>
</table>
</section>
</div>

<?php
    }else{
      echo "Error la ricerca non ha prodotto risultati";
    }
  }else{
    $query_param =  $_POST['query_param'];
  }
  $user = json_decode(fusc_query(urlencode($query_param)), true);
  $users = array();
  if($user['status'] == 1){
    $users =  $user['data'];
  }else{
?>
La ricerca per <?php echo $query_param; ?> non ha fornito alcun risultato.
<?php

  }
?>
<div class="form-panel">
<h4 class="mb"><i class="fa fa-angle-right"></i> Risultati:</h4>
<section id="no-more-tables">
  <table class="table table-bordered table-striped table-condensed cf">
    <thead class="cf">
      <tr>
        <th>Cognome</th>
        <th>Nome</th>
        <th>Data Nascita</th>
        <th>Indirizzo</th>
        <th>Tipo</th>
        <th>Ultimo Evento</th>
        <th>Data Ultimo Evento</th>
        <th>Azioni</th>
      </tr>
    </thead>
    <tbody>

<?php
foreach($users as $u){
$url = "index_admin.php?section=fusc&action=search&query=".$query_param."&id=".$u['id']
?>
  <tr>
    <td data-title="Cognome"><?php echo $u['name'] ?></td>
    <td data-title="Nome"><?php echo $u['prename'] ?></td>
    <td data-title="Data Nascita">
      <?php
      if( $u['type'] != "company"){
        echo  date("d-m-Y", strtotime($u['date_of_birth']));
      }
      ?></td>
    <td data-title="Indirizzo"><?php echo $u['address'] ?></td>
    <td data-title="Tipo"><?php echo $u['type'] ?></td>
    <td data-title="Ultimo Evento"><?php echo $u['last_title'] ?></td>
    <td data-title="Data Ultimo Evento"><?php echo date("d-m-Y", strtotime($u['last_update'])); ?></td>

    <td class="numeric" data-title="Azioni">
      <button type="button" onclick="location.href='<?php echo $url; ?>'"  class="btn btn-info" style="font-size: 10px;">Scheda Utente</button>
    </td>
  </tr>
<?php
}

?>

    </tbody>
  </table>
</section>
</div>
<?php
}
?>
