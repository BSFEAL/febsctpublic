<?php
include_once("utils/remote_calls.php");

if(array_key_exists("id", $_GET)){
  $item = json_decode(fusc_get($_GET["id"]), true);
  if($item['status'] == 1){
    $item =  $item['data'][0];

?>
<div class="form-panel">
<h4 class="mb"><i class="fa fa-angle-right"></i> <?php echo $item["name"]." ".$item["prename"]; ; ?></h4>
<b> Tipo</b>
<?php echo $item["type"]; ?><br/><br/>
<?php if($item["type"] == "person"){ ?>
  <b> Data di Nascita</b><br/>
  <?php echo  date("d-m-Y", strtotime($item["date_of_birth"])); ?><br/><br/>
  <?php if($item["date_of_death"] !="1900-01-01T00:00:00"){ ?>
  <b> Data di Morte</b> <br/>
  <?php echo  date("d-m-Y", strtotime($item["date_of_death"])); ?><br/><br/>
<?php }

} ?>

<b> Address</b> <br/>
<?php echo $item["address"]; ?><br/><br/>
<b>Ultimo Evento (<?php echo date("d-m-Y", strtotime($item['last_update'])); ?>)</b><br/>
<?php echo $item['last_title'] ?><br/><br/>
<section id="no-more-tables">  <table class="table table-bordered table-striped table-condensed cf">
  <table class="table table-bordered table-striped table-condensed cf">
    <thead class="cf">
      <tr>
        <th>Data</th>
        <th>Titolo</th>
        <th>Ufficio Responsabile</th>
        <th> Rimedio Legale</th>
        <th> Remarks</th>
      </tr>
    </thead>
    <tbody>
<?php
foreach($item["entries"] as $entry){
?>
<tr>
  <td data-title="Data"><?php echo  date("d-m-Y", strtotime($entry['timestamp'])); ?></td>
  <td data-title="Titolo"><?php echo $entry["title"] ?></td>
  <td data-title="Ufficio Responsabile"><?php echo $entry["registration_office_name"] ?></td>
  <td data-title="Rimedio Legale"><?php echo $entry["legal_remedy"] ?></td>
  <td data-title="Remarks"><?php echo $entry["remarks"] ?></td>
</tr>

<?php
}

?>
</tbody>
</table>
</section>
</div>

<?php

}else{
  echo "Utente non trovato";

} // End if search

}// end check for GET



$user = json_decode(fusc_alerts(), true);
$users = array();
if($user['status'] == 1){
  $users =  $user['data'];
}else{
?>
Non vi e' alcun avviso al momento.
<?php
  }
?>
<div class="form-panel">
<h4 class="mb"><i class="fa fa-angle-right"></i> Risultati:</h4>
<section id="no-more-tables">
  <table class="table table-bordered table-striped table-condensed cf">
    <thead class="cf">
      <tr>
        <th>Cognome</th>
        <th>Nome</th>
        <th>Data Nascita</th>
        <th>Indirizzo</th>
        <th>Tipo</th>
        <th>Ultimo Evento</th>
        <th>Data Ultimo Evento</th>
        <th>Azioni</th>
      </tr>
    </thead>
    <tbody>

<?php
foreach($users as $u){
$url = "index_admin.php?section=fusc&action=alerts&id=".$u['id']
?>
  <tr>
    <td data-title="Cognome"><?php echo $u['name']; ?></td>
    <td data-title="Nome"><?php echo $u['prename']; ?>  </td>
    <td data-title="Data Nascita"> <?php echo  date("d-m-Y", strtotime($u['date_of_birth']));  // end if?></td>
    <td data-title="Indirizzo"><?php echo $u['address'] ?></td>
    <td data-title="Tipo"><?php echo $u['type'] ?></td>
    <td data-title="Ultimo Evento"><?php echo $u['last_title'] ?></td>
    <td data-title="Data Ultimo Evento"><?php echo date("d-m-Y", strtotime($u['last_update'])); ?></td>

    <td class="numeric" data-title="Azioni">
      <button type="button" onclick="location.href='<?php echo $url; ?>'"  class="btn btn-info" style="font-size: 10px;">Scheda Utente</button>
    </td>
  </tr>
<?php
} //end foreeach

?>

    </tbody>
  </table>
</section>
</div>
