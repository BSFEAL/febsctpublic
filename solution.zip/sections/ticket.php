<?php
include_once("utils/ticket_manager.php");
include_once("utils/remote_calls.php");

$action = "main";


function get_user_list($option_name, $users, $user_selected){

  $ret = "<select name=".$option_name.">\n";
  foreach($users as $u){
      $sele = "";
      if($u['username'] == $user_selected){
        $sele = " selected ";
      }

      $ret = $ret."<option value='".$u['username']."' ".$sele."  >".$u['firstname']." ".$u['middlename']." ".$u['lastname']."[".$u['username']."]</option>\n";
  }
  $ret = $ret."<\select>";
  return $ret;

}



if(array_key_exists("action", $_GET)){
  $action = $_GET['action'];
}

/**
EDIT MANAGEMENT
**/

if(array_key_exists("save_updates", $_GET)){
  $id = $_GET["save_updates"];
  $ticket = get_single_ticket($id);
  $data= json_decode($ticket, true);
  if($data['status'] != 1){
    ?>
    <div class="col-lg-12">
      <div class="content-panel">
        <h4 style="color: red;"><i class="fa fa-angle-right" ></i> Ticket <?php echo $id; ?> not found. </h4>
      </div>
    <div>

    <?php
  }else{
    $status = $_POST["status"];
    $due_date = $_POST["due_date"];
    $outcome_text = $_POST["outcome_text"];
    $obervations = $_POST["observations"];
    $user_selected = $_POST["tester"];
    $countfiles = count($_FILES['file']['name']);

    print_r($_POST);

    $new_files = array();
    $user = $_SESSION["user"]["username"];
    // Looping all files
    for($i=0;$i<$countfiles;$i++){
        $filename = $_FILES['file']['name'][$i];
        $file_path = $user."_".$filename;

        $new_files[$filename]= $file_path;
        // Upload file
        move_uploaded_file($_FILES['file']['tmp_name'][$i],'/var/www/html/bsdsweb1/sites/ticket_export/'.$file_path );

      }
    $a = array();
    $a["status"] = $status;
    $a["due_date"] = $due_date;
    $a["outcome_text"] = $outcome_text;
    $a["observations"] = $obervations;
    $a["files"] = $new_files;
    $a["user_selected"] = $user_selected;

    $ret = update_ticket($id, urlencode(json_encode($a)));
    $dt =  json_decode($ret, true);
    if($dt["status"] == 1){
      ?>
      <div class="col-lg-12">
        <div class="content-panel">
          <h4><i class="fa fa-angle-right" ></i> Ticket update was succesfull. </h4>
        </div>
      <div>

      <?php
    }else{
      ?>
      <div class="col-lg-12">
        <div class="content-panel">
          <h4 style="color: red;"><i class="fa fa-angle-right" ></i> Error while updating <?php echo $id; ?>. </h4>
        </div>
      <div>

      <?php

    }
  }




}

if(array_key_exists("edit_ticket", $_GET)){
  $id = $_GET["edit_ticket"];
  $ticket = get_single_ticket($id);
  $data= json_decode($ticket, true);
  if($data['status'] != 1){
    ?>
    <div class="col-lg-12">
      <div class="content-panel">
        <h4 style="color: red;"><i class="fa fa-angle-right" ></i> Ticket <?php echo $id; ?> not found. </h4>
      </div>
    <div>

    <?php
  }else{

  $users_t = get_ticket_users();
  $users = json_decode($users_t, true);


  if($users['status'] != 1){
    echo "Unable to load the users";
    $users = array();
  }

 $users = $users['data'];


  ?>
<!--input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value=""-->
    <?php
    $item = $data["data"];
    ?>
    <form action="index_admin.php?section=ticket&action=opent&save_updates=<?php echo $id; ?>" method="POST" enctype='multipart/form-data' >
    <div class="col-lg-12">
      <div class="content-panel">
        <h4><i class="fa fa-angle-right"></i>  Update  Ticket <?php echo $id; ?> </h4>
        <section id="no-more-tables">
          <table class="table table-bordered table-striped table-condensed cf">
            <thead class="cf">
              <tr>
                <th>Field</th>
                <th>Value</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td data-title="Field"> Indicent</td>
                <td data-title="Value"> <?php  echo  $item["incident_related"]; ?></td>
              </tr>
              <tr>
                <td data-title="Field"> Indicent</td>
                <td data-title="Value"> <?php  echo  $item["interaction_related"]; ?></td>
              </tr>
              <tr>
                <td data-title="Field"> Status</td>
                <td data-title="Value">
                  <select name="status" class="form-control form-control-inline input-medium">
                    <?php
                    $status = $item["status"];
                    $open_selected = "";
                    $closed_selected = "";
                    if($status == "Open"){
                      $open_selected = "selected";
                    }
                    if($status == "Closed"){
                      $closed_selected = "selected";
                    }
                    ?>
                    <option value="Open" <?php echo $open_selected; ?> >Open</option>
                    <option value="Closed" <?php echo $closed_selected; ?> >Closed</option>
                  </select>
              </td>
              </tr>
              <tr>
                <td data-title="Field"> Tester</td>
                <td data-title="Value">
                <?php echo get_user_list("tester", $users, $item["user"]);?>
              </td>
              </tr>
              <tr>
                <td data-title="Field"> Assignment</td>
                <td data-title="Value"> <?php  echo  $item["assignment"]; ?></td>
              </tr>
              <tr>
                <td data-title="Field"> Brief Description</td>
                <td data-title="Value"> <?php  echo  $item["brief_description"]; ?></td>
              </tr>
              <tr>
                <td data-title="Field"> Contact Person</td>
                <td data-title="Value"> <?php  echo  $item["contact_person"]; ?></td>
              </tr>
              <tr>
                <td data-title="Field"> Created</td>
                <td data-title="Value"> <?php echo date("m-d-Y", strtotime($item["created"])); ?></td>
              </tr>
              <tr>
                <td data-title="Field"> Dependencies</td>
                <td data-title="Value"><?php echo implode(",", $item['dependencies_map']); ?></td>
              </tr>
              <tr>
                <td data-title="Field"> Due Date</td>
                <td data-title="Value">
                  <input  name="due_date" class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="<?php echo date("m-d-Y", strtotime($item["due_date"])); ?>" />
                </td>
              </tr>
              <tr>
                <td data-title="Field"> Observations</td>
                  <td data-title="Value"><input type="text" id="observations" name="observations" value="<?php echo $item['observations']; ?>" /></td>
              </tr>
              <tr>
                <td data-title="Field"> Tester Comments</td>
                <td data-title="Value">
                  <textarea id="outcome_text" name="outcome_text" rows="4" cols="50"><?php echo $item["outcome_text"]; ?></textarea>
              </td>
            </tr>
              <tr>
                <td data-title="Field"> Tester Files</td>
                <td data-title="Value">
                  <input type="file" name="file[]" id="file" multiple /><br/>
                    <?php
                    foreach($item['files'] as $key => $value){
                        ?>
                        <input type="checkbox" id="<?php echo $key; ?>" name="<?php echo $key; ?>" checked value="<?php echo $key; ?>"><?php echo $key; ?><br/>
                        <?php
                        //echo "- ".$key."<br/>";
                    }
                  ?>
              </td>
              </tr>


          </tbody>
        </table>
        <input type="submit" name="clear_values" value="Save Changes" class="btn btn-info" style="font-size: 10px; background-color: green; width:100%;">

  </div>
<div>
</form>
  <?php
}
}


/**
DELETE MANAGEMENT
**/
if(array_key_exists("delete_ticket", $_GET)){
  $id = $_GET["delete_ticket"];
  $ticket = get_single_ticket($id);
  $data= json_decode($ticket, true);
  if($data['status'] != 1){
    ?>
    <div class="col-lg-12">
      <div class="content-panel">
        <h4 style="color: red;"><i class="fa fa-angle-right" ></i> Ticket <?php echo $id; ?> not found. </h4>
      </div>
    <div>
    <?php
  }else{

  ?>
<!--input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value=""-->
<form action="index_admin.php?section=ticket&action=opent&save_updates" method="POST">
<div class="col-lg-12">
  <div class="content-panel">
    <h4><i class="fa fa-angle-right"></i>  <?php echo $id; ?></h4>
    <?php
    print_r($data);
    ?>
  </div>
<div>
</form>
  <?php
}
}

if(array_key_exists("delete_ticket_confirm", $_GET)){
  echo "Deleting ticket: ".$_GET["delete_ticket_confirm"];
  $ticket = delete_ticket($_GET["delete_ticket_confirm"]);
}

if(array_key_exists("save_tickets", $_GET)){
  $excel = $_GET["path"];
  $ret = save_tickets(json_encode($_POST), $excel);
  $data= json_decode($ret, true);
  if($data['status'] != 1){
    ?>
      <h4><i class="fa fa-angle-right"></i>  Errore nell caricare i tickets </h4>
    <?php
    echo $data['data'];
  }else{
    $num = 0;
    $tickets = "";
    foreach($data['data'] as $d){
      if($num == 0){
          $tickets = $tickets." ".$d;
      }else{
          $tickets = $tickets.", ".$d;
      }

      $num += 1;

    }
    ?>
      <h3><i class="fa fa-angle-right"></i>   <?php echo $num; ?> tickets caricati correttamente</h3>
    <?php
  }

}

if($action == "opent"){
  $query = "";
  $status = "";
  $date_from = "";
  $date_to = "";

  if(array_key_exists("query", $_GET)){
    $query = $_POST["qr"];
    $status = $_POST["status"];
    $date_from = $_POST["from"];
    $date_to = $_POST["to"];
  }

  $tickets = get_tickets($query, $status, $date_from, $date_to);
  $tickets= json_decode($tickets, true);
  if($tickets['status'] != 1){
    echo "Error nel caricare i tickets";
    $data = [];
  }
  ?>
  <h3><i class="fa fa-angle-right"></i>  Ticket Management - Tickets </h2>
<!--input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value=""-->
<form action="index_admin.php?section=ticket&action=opent&query" method="POST">
<div class="col-lg-12">
  <div class="content-panel">
    <h4><i class="fa fa-angle-right"></i> Query </h4>
    <section id="no-more-tables">
      <table class="table table-bordered table-striped table-condensed cf">
        <thead class="cf">
          <tr>
            <th>Query</th>
            <th>Type</th>
            <th>From</th>
            <th>To</th>
            <th>Actions</th>
          <tr/>
        </thead>
        <tbody>
          <tr>
            <td data-title="Query"><input type"text"  class="form-control form-control-inline input-medium" name="qr" value="<?php echo $query; ?>"></td>
            <td data-title="Type">
                <select name="status" class="form-control form-control-inline input-medium">
                  <?php
                  $open_selected = "";
                  $closed_selected = "";
                  if($status == "Open"){
                    $open_selected = "selected";
                  }
                  if($status == "Closed"){
                    $closed_selected = "selected";
                  }
                  ?>
                  <option value="Open" <?php echo $open_selected; ?> >Open</option>
                  <option value="Closed" <?php echo $closed_selected; ?> >Closed</option>

                </select>
            </td>
            <td data-title="From">
              <input  name="from" value="<?php echo $date_from; ?>"  class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="">
            </td><td data-title="To">
              <input  name="to"  value="<?php echo $date_to; ?>" class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="">
            </td> <td data-title="Action">
            <input type="submit" name="query" value="Query" class="btn btn-info" style="font-size: 10px; background-color: green; width:100%;">
            </form>
            <form action="index_admin.php?section=ticket&action=opent&clear" method="POST">
            <input type="submit" name="clear_values" value="Clear" class="btn btn-info" style="font-size: 10px; width:100%;">
            </form>
          </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="col-lg-12">
    <div class="content-panel">
      <h4><i class="fa fa-angle-right"></i> Results </h4>
      <section id="no-more-tables">
        <table class="table table-bordered table-striped table-condensed cf">
          <thead class="cf">
            <tr>
              <th>Incident Related</th>
              <th>Interaction Related</th>
              <th>Assignment</th>
              <th>Description</th>
              <th>Contact Person</th>
              <th>Created</td>
              <th>Data di fine</th>
              <th>Dependencies Map</th>
              <th>Tester</th>
              <th>Osservazioni</th>
              <th>Outcomes</th>
              <th>Action</th>


            </tr>
          </thead>
          <tbody>
            <?php
            foreach($tickets["data"] as  $key =>$d){
                $id = $key;

              ?>
              <tr>
                <td data-title="Incident Related"><?php echo $d["incident_related"]; ?></td>
                <td data-title="Interaction Related"><?php echo $d["interaction_related"]; ?></td>
                <td data-title="Assignment"><?php echo $d["assignment"]; ?></td>
                <td data-title="Description"><?php echo $d["brief_description"]; ?></td>
                <td data-title="Contact Person"><?php echo $d["contact_person"]; ?></td>
                <td data-title="Created at"><?php echo  date("m-d-Y", strtotime($d["created"])); ?></td>
                <td data-title="Created at"><?php echo date("m-d-Y", strtotime($d["due_date"])); ?></td>
                <td data-title="Dependencies Map"><?php echo implode(",", $d['dependencies_map']); ?></td>
                <td data-title="Tester"><?php echo $d["user"]; ?>  </td>
                <td data-title="Osservazioni"><?php echo $d["observations"]; ?>  </td>
                <td data-title="Outcomes"><?php echo $d["outcomes"]; ?>  </td>
                <td class="numeric" data-title="Action">
                  <button type="button" onclick="location.href='index_admin.php?section=ticket&action=opent&edit_ticket=<?php echo $id; ?>';" class="btn btn-info" style="font-size: 10px;">Edit</button>
                  <button type="button"  onclick="location.href='index_admin.php?section=ticket&action=opent&delete_ticket=<?php echo $id; ?>';"  class="btn btn-danger" style="font-size: 10px;">Delete</button>
                </td>
              </tr>
              <?php
            }

            ?>


          </tbody>
        </table>
      </section>
    </div>
    <!-- /content-panel -->
  </div>
  <?php

}

if($action == "excel"){

?>

<?php
if(array_key_exists("load_excel", $_GET)){
  foreach($_FILES as $file){
     $local_path = "/var/www/html/bsdsweb1/sites/files_upload/".$file['name'][0];
     if(move_uploaded_file($file['tmp_name'][0], $local_path)){
       echo "<h2/>Excel Uploaded</h2>";
       $data =  load_excel($local_path);
       $data= json_decode($data, true);
       if($data['status'] != 1){
         continue;
       }

       $users_t = get_ticket_users();
       $users = json_decode($users_t, true);
       if($users['status'] != 1){
         continue;
       }
       print_tk_table($data['data'], $users['data'], $local_path);
     }else{
       echo "Upload Failed";
     }

  }
}
?>

  <div class="col-lg-4 col-md-4 col-sm-4 mb">
    <h3><i class="fa fa-angle-right"></i>  Ticket Management - Load Excel </h3>
    <div class="content-panel pn" style="align: center;">
    <b> Upload</b> Your excel file to start the process.<br/><br/> <br/>
  <form id="fileupload" action="<?php echo curPageURL(). "&load_excel"; ?>" method="POST" enctype="multipart/form-data">
    <noscript>
        <input type="hidden" name="redirect" value="http://blueimp.github.io/jQuery-File-Upload/">
      </noscript>
    <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
    <div class="row fileupload-buttonbar">
      <div class="col-lg-8" >
        <!-- The fileinput-button span is used to style the file input field as button -->
        <span class="btn btn-success fileinput-button" style="background: red;">
          <i class="glyphicon glyphicon-plus"></i>
          <span>Select your Excel.</span>
        <input type="file" name="files[]" multiple>
        </span>
        <br/>
        <button type="submit" class="btn btn-theme start" style="background: red; height:50px; width:300px;" >
          <i class="glyphicon glyphicon-upload"></i>
          <span>Upload</span>
          </button>
        <bf/>

      <!-- /col-lg-5 -->
    </div>

  </form>
</div></div>
<?php
}



function print_tk_table($data, $users,  $local_path){
  $eot =  date('m-j-Y', strtotime ('5 weekdays'));

?>
<h3><i class="fa fa-angle-right"></i>  Ticket Management - Open Tickets </h3>
<!--input class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="" -->
<form id="ticket_save" action="<?php echo curPageURL(). "&save_tickets&path=".$local_path; ?>" method="POST" enctype="multipart/form-data">
<div class="col-lg-12">
  <div class="content-panel">
    <!--h4><i class="fa fa-angle-right"></i> Tickets </h4-->
    <section id="no-more-tables">
      <table class="table table-bordered table-striped table-condensed cf">
        <thead class="cf">
          <tr>
            <th>Incident Related</th>
            <th>Interaction Related</th>
            <th>Assignment</th>
            <th>Brief Description</th>
            <th>Contact Person</th>
            <th>Dependencies Map</th>
            <th>Osservazioni</th>
            <th>Tester</th>
            <th>Due Date</th>
            <th>Consider</th>

          </tr>
        </thead>
        <tbody>
  <?php foreach($data as $d){
      $id = $d['incident_related']."_".$d['interaction_related'];
  ?>

          <tr>

            <td data-title="Incident Related<"><?php echo $d['incident_related'];?></td>
            <td data-title="Interaction Related"><?php echo $d['interaction_related']; ?></td>
            <td data-title="Assignment"><?php echo $d['assignment']; ?></td>
            <td data-title="Brief Description"><?php echo $d['brief_description']; ?></td>
            <td data-title="Contact Person"><?php echo $d['contact_person']; ?></td>
            <td data-title="Dependencies Map"><?php echo implode(",", $d['dependencies_map']); ?></td>
            <td data-title="Osservazioni">
              <input type="text" name="oss_<?php echo $id; ?>" />
            </td>
            <td data-title="Tester"><?php echo get_user_list($id."_user", $users, ""  ) ?></td>
            <td data-title="Due Date"> <input name="date_<?php echo $id; ?>" class="form-control form-control-inline input-medium default-date-picker" size="16" type="text" value="<?php echo $eot; ?>"></td>
            <td data-title="Consider"> <input type="checkbox" name="consider_<?php echo $id; ?>" checked /> </td>
          </tr>
  <?php } ?>
        </tbody>
      </table>
      <button type="submit" class="btn btn-theme start" style="background: red; height:50px; width:100%;" >
        <i class="glyphicon glyphicon-upload"></i>
        <span>Salva Tickets</span>
        </button>
    </section>
  </div>
  <!-- /content-panel -->
</div>
</form>
<br/><br/>
<?php


}

?>
