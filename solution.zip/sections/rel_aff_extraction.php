<h3><i class="fa fa-angle-right"></i>  Estrazione Relazioni D'Affari</h2>
<div class="row mt">
  <div class="col-lg-12">
    <div class="form-panel">
      <h4 class="mb"><i class="fa fa-angle-right"></i> Ricerca utente:</h4>
      <form class="form-inline" role="form" action="index_admin.php?section=relaff&action=user" method="POST">
        <div class="form-group">
          <label class="sr-only" for="exampleInputEmail2"></label>
          <input type="text" class="form-control" id="user_info" name="user_info" placeholder="Inseriesce il #utente o il nome">
        </div>
        <button type="submit" class="btn btn-theme">Ricerca</button>
      </form>
    </div>
  </div>
</div>

<?php
if(array_key_exists("action", $_GET) and $_GET['action'] == "user"){
  $user_info = $_POST['user_info'];
  include_once("utils/remote_calls.php");
  $user = json_decode(search_partner_call($user_info), true);
  $users = array();
  if($user['status'] == 1){
    $users =  $user['data'];
  }else{

?>
La ricerca per <?php echo $user_info; ?> non ha fornito alcun risultato.
<?php

  }
?>
<div class="form-panel">
<h4 class="mb"><i class="fa fa-angle-right"></i> Risultati:</h4>
<section id="no-more-tables">
  <table class="table table-bordered table-striped table-condensed cf">
    <thead class="cf">
      <tr>
        <th>Nome</th>
        <th>Cognome</th>
        <th>Data Nascita</th>
        <th>Indirizzo</th>
        <th>Azioni</th>
      </tr>
    </thead>
    <tbody>

<?php
foreach($users as $u){
?>
  <tr>
    <td data-title="Nome"><?php echo $u['firt_name'] ?></td>
    <td data-title="Cognome"><?php echo $u['last_name'] ?></td>
    <td data-title="Data Nascita"><?php echo $u['birth_date'] ?></td>
    <td data-title="Indirizzo"><?php echo $u['address'] ?></td>
    <td class="numeric" data-title="Azioni">
      <button type="button" onclick="window.open('index_admin.php?doc_extract=<?php echo $u['partner_no'] ?>');"  class="btn btn-info" style="font-size: 10px;">Estrai Documento</button>
    </td>
  </tr>
<?php
}

?>

    </tbody>
  </table>
</section>
</div>
<?php
}
?>
