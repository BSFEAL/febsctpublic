<?php
if(array_key_exists("doc_extract", $_GET)){
  include_once("utils/remote_calls.php");
  $wd = json_decode(generate_crel($_GET['doc_extract']), true);
  if($wd['status'] == 1){
    header("Location: http://159.69.83.224/bsdsweb1/sites/doc_exports/".$wd['data']);
  }else{
    header("Location: http://159.69.83.224/bsdsweb1/sites/index_admin.php?section=relaf&extract_error");
  }
  exit();
}


session_start();




include_once("utils/permissions.php");
include_once("sections/sections_manager.php");

// IDENTITY CHECK
if(!array_key_exists('user', $_SESSION)){
  header("Location: index.php");
  exit();
}

$user = $_SESSION['user'];
$permissions = $user['permissions'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="BancaStato">
  <title>BacaStato - DS Service 1</title>

  <!-- Favicons -->
  <link href="https://www.bancastato.ch/.resources/bancastato-templating-light/webresources/img/favicons/favicon.ico" rel="icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <script src="lib/chart-master/Chart.js"></script>
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg" style="background-color: white">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <div class="sidebar-toggle-box">
          <img src="https://www.bancastato.ch/.resources/bancastato-templating-light/webresources/img/logo-bancastato.svg" width="50%" />
        <br/>
      </div>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          <!-- settings start -->
          <!-- inbox dropdown end -->
          <!-- notification dropdown start-->
          <li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-bell-o"></i>
              <span class="badge bg-warning">0</span>
              </a>
            <ul class="dropdown-menu extended notification">
              <div class="notify-arrow notify-arrow-yellow"></div>
              <li>
                <p class="yellow">You have no new notifications</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-success"><i class="fa fa-plus"></i></span>
                  demo regisgtration.
                  <span class="small italic">time.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all notifications</a>
              </li>
            </ul>
          </li>
        </ul>
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" style="background-color: red; "  href="index.php?logout">Logout</a></li>
        </ul>
      </div>
    </header>
    <aside>
      <div id="sidebar" class="nav-collapse " style="background-color: white">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/user.png" class="img-circle" width="80"></a></p>
          <h5 class="centered" style="color: black"><?php echo $_SESSION['user']['username']; ?></h5>
          <li class="mt">
            <?php
              $link_action = "class=\"active\"";

              $section = "";
              if(array_key_exists("section", $_GET)){
                $link_action = "";
                $section = $_GET['section'];
              }

              $action = "";

              if(array_key_exists("action", $_GET)){
                  $action = $_GET['action'];
              }
            ?>
            <a  <?php echo $link_action; ?> href="index_admin.php">
              <i class="fa fa-dashboard"></i>
              <span>Main</span>
              </a>
          </li>
          <?php
            if(check_permission("Fusc", $permissions)){
              $link_action = "";
              if($section == "fusc"){
                $link_action = "class=\"active\"";
              }

          ?>
          <li class="sub-menu">
            <a <?php echo $link_action; ?> href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span>FUSC</span>
              </a>
            <ul class="sub">
              <li><a href="index_admin.php?section=fusc&action=search">Ricerca per utente</a></li>
              <li><a href="index_admin.php?section=fusc&action=alerts">Ultimi Avvisi</a></li>
            </ul>
          </li>
        <?php } ?>
          <?php
            if(check_permission("Reports", $permissions)){
              $link_action = "";
              if($section == "relaff"){
                $link_action = "class=\"active\"";
              }

          ?>
          <li class="sub-menu">
            <a <?php echo $link_action; ?> href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span>Reports</span>
              </a>
            <ul class="sub">
              <li><a href="index_admin.php?section=relaff">Conferma relazione d'affari</a></li>
            </ul>
          </li>
        <?php } ?>
          <?php
            if(check_permission("ticket", $permissions)){
              $link_action = "";
              if($section == "ticket"){
                $link_action = "class=\"active\"";
              }
          ?>
          <li class="sub-menu">
            <a  <?php echo $link_action; ?> href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span>Ticket Management [Admin]</span>
              </a>
            <ul class="sub">
              <li><a <?php if($action  == "opent"){ echo "style=\"color: white;\""; } ?> href="index_admin.php?section=ticket&action=opent">Gestisci Ticket Aperti</a></li>
            </ul>
            <ul class="sub">
              <li><a <?php if($action  == "excel"){ echo "style=\"color: white;\""; } ?> href="index_admin.php?section=ticket&action=excel">Carica Excel</a></li>
            </ul>

            <li class="sub-menu">
              <a  <?php echo $link_action; ?> href="javascript:;">
                <i class="fa fa-desktop"></i>
                <span>Ticket Management</span>
                </a>
              <ul class="sub">
                <li><a <?php if($action  == "tmot"){ echo "style=\"color: white;\""; } ?> href="index_admin.php?section=tmot&action=tgest">Gestisci I Tuoi Ticket Aperti</a></li>
              </ul>
          </li>
          <?php } ?>
          <?php
            if(check_permission("qad", $permissions)){
              $link_action = "";
              if($section == "qad"){
                $link_action = "class=\"active\"";
              }

          ?>
          <li class="sub-menu">
            <a <?php echo $link_action; ?> href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span>Q&amp;A</span>
              </a>
            <ul class="sub">
              <li><a href="index_admin.php?section=qad">Q&amp;A</a></li>
            </ul>
            <ul class="sub">
              <li><a href="index_admin.php?section=qads">Q&amp;A - Sorgenti dati</a></li>
            </ul>
          </li>
        <?php } ?>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <section id="main-content">
      <section class="wrapper">
        <div class="row" style="min-height: 650px; height: auto !important;  height: 750px;">
          <?php
              if(array_key_exists("section", $_GET)){
                  get_section($_GET['section']);
              }else{
                  get_section("main");
              }

          ?>
          </div>

      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
    <!--footer class="site-footer" style="background-color: red; ">
      <div class="text-center">
        <div class="credits">
          &copy; <a href="http://www.bancastato.ch">Banca dello Stato del Cantone Ticino</a>
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer-->
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>

  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="lib/jquery.scrollTo.min.js"></script>
  <script src="lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="lib/common-scripts.js"></script>
  <script type="text/javascript" src="lib/gritter/js/jquery.gritter.js"></script>
  <script type="text/javascript" src="lib/gritter-conf.js"></script>
  <!--script for this page-->
  <script src="lib/sparkline-chart.js"></script>
  <script src="lib/zabuto_calendar.js"></script>

  <script type="application/javascript">
    $(document).ready(function() {
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });
    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
  </script>

  <!--script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="lib/jquery.scrollTo.min.js"></script>
  <script src="lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <!--script src="lib/common-scripts.js"></script-->
  <!--script for this page-->
  <script src="lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script type="text/javascript" src="lib/bootstrap-fileupload/bootstrap-fileupload.js"></script>
  <script type="text/javascript" src="lib/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="lib/bootstrap-daterangepicker/date.js"></script>
  <script type="text/javascript" src="lib/bootstrap-daterangepicker/daterangepicker.js"></script>
  <script type="text/javascript" src="lib/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
  <script type="text/javascript" src="lib/bootstrap-daterangepicker/moment.min.js"></script>
  <script type="text/javascript" src="lib/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
  <script src="lib/advanced-form-components.js"></script>
</body>


</html>
