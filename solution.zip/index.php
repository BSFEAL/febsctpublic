<?php
session_start();
include_once("./utils/remote_calls.php");



if(array_key_exists("logout", $_GET)){
  unset($_SESSION['user']);
  session_destroy();

}

if(array_key_exists('user', $_SESSION)){
  header("Location: index_admin.php");
  exit();
}

$show_error = false;
if( array_key_exists("uname", $_POST)){
  $res = login_user($_POST['uname'], $_POST['psw']);
  $res = json_decode($res, true);
  if($res['status'] == 'true'){
    $_SESSION['user'] =  $res['user'];
    header("Location: index_admin.php");
    exit();
  }else{
    $show_error = true;
  }
}



?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <title>BacaStato - DS Service 1</title>

  <!-- Favicons -->
  <link href="https://www.bancastato.ch/.resources/bancastato-templating-light/webresources/img/favicons/favicon.ico" rel="icon">
  <!--link href="img/apple-touch-icon.png" rel="apple-touch-icon"-->

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <script src="lib/chart-master/Chart.js"></script>

</head>

<body>
  <header class="header black-bg" style="background-color: white">
    <div class="sidebar-toggle-box">

        <img src="https://www.bancastato.ch/.resources/bancastato-templating-light/webresources/img/logo-bancastato.svg" width="50%" />
        <h3>DS Platform 1</h3>
      <br/>
    </div>
    <!--logo start-->

    <!--logo end-->

      <!--  notification end -->
    </div>
  </header>
  <section id="container">
    <div style="
  display: inline-block;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  width: 250px;
  height: 200px;
  margin: auto;
  background-color: #f3f3f3;">
  <form action="index.php" method="post">
    <div class="imgcontainer">
      <img src="https://www.bancastato.ch/.resources/bancastato-templating-light/webresources/img/favicons/favicon.ico" alt="Login" class="Login">
      <label for="uname"><b>Login</b></label> <br/>
    </div>

    <div class="container">
      <?php
        if($show_error){
          ?>
           <b>Wrong Username or Password. <br/>Try again.</b><br/><br/>
      <?php
        }
      ?>

      <input type="text" placeholder="Enter Username" name="uname" required>
      <label for="uname"><b>Username</b></label>
      <br/><br/>
      <input type="password" placeholder="Enter Password" name="psw" required>
      <label for="psw"><b>Password</b></label>
      <br/><br/>
      <button type="submit">Login</button><br/>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <!--div class="container" style="background-color:#f1f1f1">
      <button type="button" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div-->
  </form>
</div>
  </section>

</body>
